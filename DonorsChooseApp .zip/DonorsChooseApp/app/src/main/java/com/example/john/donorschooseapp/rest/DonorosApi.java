package com.example.john.donorschooseapp.rest;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

/**
 * Created by john on 1/23/17.
 */
public interface DonorosApi {

    @GET("json_feed.html")
    Call<ResponseBody> getData(@Query(value = "keywords", encoded = true) String keyword,
                                 @Query("max")String max,
                                 @Query("state")String state,
                                 @Query("sortBy")String sortBy,
                                 @Query(value = "costToCompleteRange", encoded = true)String costToCompleteRange,
                                 @Query("APIKey")String APIKey);

    @GET("json_feed.html")
    Call<ResponseBody> getDataWithoutKeyword(@Query("max")String max,
                          @Query("state")String state,
                          @Query("sortBy")String sortBy,
                          @Query(value = "costToCompleteRange", encoded = true)String costToCompleteRange,
                          @Query("APIKey")String APIKey);
}
