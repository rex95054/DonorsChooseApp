package com.example.john.donorschooseapp.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

import com.example.john.donorschooseapp.R;
import com.example.john.donorschooseapp.model.ProjectDetails;

import java.util.ArrayList;

/**
 * Created by john on 1/23/17.
 */
public class statsActivity extends AppCompatActivity {
    ArrayList<ProjectDetails> objs;
    TextView percentFund;
    TextView donorsNo;
    TextView costTotal;
    TextView studentsNo;
    TextView priceTotal;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.stats_layout);
        Intent intent = getIntent();
        objs = intent.getParcelableArrayListExtra("list_items");
        percentFund = (TextView) findViewById(R.id.percentageFunded);
        donorsNo = (TextView) findViewById(R.id.donors);
        costTotal = (TextView) findViewById(R.id.cost);
        studentsNo = (TextView) findViewById(R.id.noOfStudents);
        priceTotal = (TextView) findViewById(R.id.totalPrice);
        setTexts();
    }

    public void setTexts() {
        int no = 5;
        int percentFunded = 0;
        int donors = 0;
        int cost = 0;
        int students = 0;
        int price = 0;
        for(ProjectDetails obj : objs) {
            percentFunded += obj.getPercentFunded();
            donors += obj.getNumDonors();
            cost += obj.getCostToComplete();
            students += obj.getNumStudents();
            price += obj.getTotalPrice();
        }

        String text = (percentFunded/no) + " " + "(Average Percent Funded)";
        percentFund.setText(text);
        text = (donors/no) + " " + "(Average  Number of Donors)";
        donorsNo.setText(text);
        text = "$"+(cost/no) + " " + "(Average Cost To Complete)";
        costTotal.setText(text);
        text = (students/no) + " " + "(Average  Number of Students)";
        studentsNo.setText(text);
        text = "$"+(price/no) + " " + "(Average Total Price)";
        priceTotal.setText(text);
    }
}
