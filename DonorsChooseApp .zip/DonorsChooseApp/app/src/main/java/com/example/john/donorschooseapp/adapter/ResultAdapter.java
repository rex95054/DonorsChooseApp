package com.example.john.donorschooseapp.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.john.donorschooseapp.R;
import com.example.john.donorschooseapp.model.ProjectDetails;

import java.util.ArrayList;

/**
 * Created by john on 1/22/17.
 */
public class ResultAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    ArrayList<ProjectDetails> data;
    Context context;
    private LayoutInflater inflater;

    public ResultAdapter(Context context, ArrayList<ProjectDetails> data) {
        this.context = context;
        this.data = data;
        this.inflater = LayoutInflater.from(context);
    }


    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.result_list_row, parent, false);
        RecyclerView.ViewHolder holder = new myViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        myViewHolder myHolder = (myViewHolder)holder;
        Log.i("results", data.get(position).getTitle());
        int no = position+1;
        myHolder.title_no.setText("Title" + no);
        myHolder.titleView.setText(data.get(position).getTitle());
        myHolder.url.setClickable(true);
        myHolder.url.setMovementMethod(LinkMovementMethod.getInstance());
        String text = "<a href='"+data.get(position).getProposalURL()+"'> Go to the website </a>";
        myHolder.url.setText(Html.fromHtml(text));
        String cost = "$" + data.get(position).getCostToComplete().toString();
        myHolder.costToComplete.setText(cost);
        myHolder.description.setText(data.get(position).getShortDescription());
        myHolder.description.setMovementMethod(new ScrollingMovementMethod());
    }

    @Override
    public int getItemCount() {
        return data.size();
    }


    public static class myViewHolder extends RecyclerView.ViewHolder {
        public TextView titleView;
        public TextView url;
        public TextView costToComplete;
        public TextView description;
        public TextView title_no;


        public myViewHolder(View view) {
            super(view);
            title_no = (TextView) view.findViewById(R.id.title_no);
            titleView = (TextView) view.findViewById(R.id.list_title);
            url = (TextView) view.findViewById(R.id.url);
            costToComplete = (TextView) view.findViewById(R.id.cost);
            description = (TextView) view.findViewById(R.id.desc);
        }
    }
}
