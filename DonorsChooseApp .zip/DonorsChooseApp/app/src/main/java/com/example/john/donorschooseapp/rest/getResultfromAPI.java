package com.example.john.donorschooseapp.rest;

import android.app.IntentService;
import android.content.Intent;
import android.util.Log;

import com.example.john.donorschooseapp.model.ProjectDetails;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;

import okhttp3.OkHttpClient;
import okhttp3.ResponseBody;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Created by john on 1/22/17.
 */
public class getResultfromAPI extends IntentService{
    String search_param;
    static final String BASE_URL = "https://api.donorschoose.org/common/";
    final String MAX = "5";
    final String state = "CA";
    final String sortOder = "0";
    final String cost = "0+TO+2000";
    public static final String ACTION_MyService = "com.example.androidintentservice.RESPONSE";
    private static Retrofit retrofit = null;
    private final static String API_KEY = "DONORSCHOOSE";

    /**
     * Creates an IntentService.  Invoked by your subclass's constructor.
     *
     * @param name Used to name the worker thread, important only for debugging.
     */
    public getResultfromAPI(String name) {
        super(name);
    }

    public getResultfromAPI() {
        super("IntentService called");
    }




    @Override
    protected void onHandleIntent(Intent intent) {
        search_param = intent.getStringExtra("search_param");
        StringBuffer keyword = new StringBuffer();
        if(! search_param.equals("emptySearchParam")) {
            if(search_param.contains(" ")) {
                String [] words = search_param.split("//s");
                int  i = 0;
                keyword.append("\"");
                while(i < words.length) {
                    if(i != words.length - 1) {
                        keyword.append(words[i] + "%2B");
                    }
                    else {
                        keyword.append(words[i]);
                    }
                    i++;
                }
                keyword.append("\"");
            }
            else {
                keyword.append(search_param);
            }
        }

        DonorosApi apiService = getClient().create(DonorosApi.class);
        Call<ResponseBody> call;
        if(! search_param.equals("emptySearchParam")) {
            call = apiService.getData(keyword.toString(), MAX, state, sortOder, cost, API_KEY);
        }
        else {
            call = apiService.getDataWithoutKeyword(MAX, state, sortOder, cost, API_KEY);
        }


        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                String result = "";
                if(response.isSuccessful()) {
                    try {
                        result = response.body().string();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    ArrayList<ProjectDetails> objects = new ArrayList<ProjectDetails>();
                    try {
                      objects = getProjectDetails(result);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    Log.i("result", String.valueOf(objects.size()));
                    Intent broadcastIntent = new Intent(ACTION_MyService);
                    broadcastIntent.putParcelableArrayListExtra("result",objects);
                    sendBroadcast(broadcastIntent);

                    //Log.i("result", String.valueOf(objects.size()));
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                Log.e("Retrofit", t.toString());
            }
        });



    }

    public static Retrofit getClient() {
        HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
        interceptor.setLevel(HttpLoggingInterceptor.Level.BASIC);
        OkHttpClient client = new OkHttpClient.Builder().addInterceptor(interceptor).build();
// set your desired log level
        if (retrofit==null) {
            retrofit = new Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .addConverterFactory(GsonConverterFactory.create())
                    .client(client)
                    .build();
        }
        return retrofit;
    }


    public ArrayList<ProjectDetails> getProjectDetails(String response) throws JSONException {
        JSONObject obj = new JSONObject(response);
        JSONArray proposals = obj.getJSONArray("proposals");
        ArrayList<ProjectDetails> result = new ArrayList<ProjectDetails>();
        for (int i = 0; i < proposals.length(); i++) {
            JSONObject currentProposal = proposals.getJSONObject(i);
            result.add(new ProjectDetails(currentProposal.getString("title"),
                    currentProposal.getString("shortDescription"),
                    currentProposal.getString("proposalURL"),
                    Double.parseDouble(currentProposal.getString("costToComplete")),
                    Double.parseDouble(currentProposal.getString("percentFunded")),
                    Double.parseDouble(currentProposal.getString("totalPrice")),
                    Integer.parseInt(currentProposal.getString("numDonors")),
                    Integer.parseInt(currentProposal.getString("numStudents"))));
        }

        return result;
    }



}
