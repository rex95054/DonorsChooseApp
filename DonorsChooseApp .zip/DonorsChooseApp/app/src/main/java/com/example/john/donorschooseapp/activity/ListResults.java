package com.example.john.donorschooseapp.activity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.example.john.donorschooseapp.R;
import com.example.john.donorschooseapp.adapter.ResultAdapter;
import com.example.john.donorschooseapp.model.ProjectDetails;
import com.example.john.donorschooseapp.rest.getResultfromAPI;

import java.util.ArrayList;

/**
 * Created by john on 1/22/17.
 */
public class ListResults extends AppCompatActivity {
    private RecyclerView mRecyclerView;
    private ResultAdapter adapter;
    private String search_param;
    private MyBroadcastReceiver myBroadcastReceiver;
    ArrayList<ProjectDetails> objs;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.result_list);
        mRecyclerView = (RecyclerView) findViewById(R.id.recycler_view);
        myBroadcastReceiver = new MyBroadcastReceiver();
        Intent intent = getIntent();
        search_param = intent.getStringExtra("search_param");
        Intent getResultIntent = new Intent(this, getResultfromAPI.class);
        getResultIntent.putExtra("search_param", search_param.toString());
        startService(getResultIntent);
        IntentFilter intentFilter = new IntentFilter(getResultfromAPI.ACTION_MyService);
        intentFilter.addCategory(Intent.CATEGORY_DEFAULT);
        registerReceiver(myBroadcastReceiver, intentFilter);
        Button getstatsBtn = (Button) findViewById(R.id.statsBtn);
        getstatsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), statsActivity.class);
                intent.putParcelableArrayListExtra("list_items", objs);
                startActivity(intent);
            }
        });

    }

    public class MyBroadcastReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            Log.i("br", "broadcast received");
            objs = intent.getParcelableArrayListExtra("result");
            Log.i("result2", String.valueOf(objs.size()));
            for(ProjectDetails obj : objs) {
                Log.i("result", obj.getTitle());
            }
            setAdapter(objs);
        }
    }

    public void setAdapter(ArrayList<ProjectDetails> objs) {
        adapter = new ResultAdapter(getApplicationContext(), objs);
        mRecyclerView.setAdapter(adapter);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
    }
    @Override
    protected void onDestroy() {
        unregisterReceiver(myBroadcastReceiver);
        super.onDestroy();
    }

}
