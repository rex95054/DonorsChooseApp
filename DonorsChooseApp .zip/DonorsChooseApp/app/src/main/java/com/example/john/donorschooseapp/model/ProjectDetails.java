package com.example.john.donorschooseapp.model;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by john on 1/22/17.
 */
public class ProjectDetails implements Parcelable {
    String title;
    String shortDescription;
    String proposalURL;
    Double costToComplete;
    Double percentFunded;
    Double totalPrice;
    int numDonors;
    int numStudents;

    public ProjectDetails(String title, String shortDescription, String proposalURL, Double costToComplete, Double percentFunded,
                          Double totalPrice, int numDonors, int numStudents) {
        this.title = title;
        this.shortDescription = shortDescription;
        this.proposalURL = proposalURL;
        this.costToComplete = costToComplete;
        this.percentFunded = percentFunded;
        this.totalPrice = totalPrice;
        this.numDonors = numDonors;
        this.numStudents = numStudents;
    }

    public ProjectDetails(Parcel parcel) {
        this.title = parcel.readString();
        this.shortDescription = parcel.readString();
        this.proposalURL = parcel.readString();
        this.costToComplete = parcel.readDouble();
        this.percentFunded = parcel.readDouble();
        this.totalPrice = parcel.readDouble();
        this.numDonors = parcel.readInt();
        this.numStudents = parcel.readInt();
    }

    public Double getPercentFunded() {
        return percentFunded;
    }

    public void setPercentFunded(Double percentFunded) {
        this.percentFunded = percentFunded;
    }

    public Double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(Double totalPrice) {
        this.totalPrice = totalPrice;
    }

    public int getNumDonors() {
        return numDonors;
    }

    public void setNumDonors(int numDonors) {
        this.numDonors = numDonors;
    }

    public int getNumStudents() {
        return numStudents;
    }

    public void setNumStudents(int numStudents) {
        this.numStudents = numStudents;
    }


    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getProposalURL() {
        return proposalURL;
    }

    public void setProposalURL(String proposalURL) {
        this.proposalURL = proposalURL;
    }

    public String getShortDescription() {
        return shortDescription;
    }

    public void setShortDescription(String shortDescription) {
        this.shortDescription = shortDescription;
    }

    public Double getCostToComplete() {
        return costToComplete;
    }

    public void setCostToComplete(Double costToComplete) {
        this.costToComplete = costToComplete;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(title);
        dest.writeString(shortDescription);
        dest.writeString(proposalURL);
        dest.writeDouble(costToComplete);
        dest.writeDouble(percentFunded);
        dest.writeDouble(totalPrice);
        dest.writeInt(numDonors);
        dest.writeInt(numStudents);
    }

    public static Creator<ProjectDetails> CREATOR = new Creator<ProjectDetails>() {

        @Override
        public ProjectDetails  createFromParcel(Parcel source) {
            return new ProjectDetails(source);
        }

        @Override
        public ProjectDetails[] newArray(int size) {
            return new ProjectDetails[size];
        }

    };
}
